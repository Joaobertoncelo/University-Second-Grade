import javax.swing.JFrame;

public class TesteJanelaBotaoOpcao{
   public static void main(String[] args){
      JanelaBotaoOpcao janela = new JanelaBotaoOpcao();
      janela.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      janela.setSize(300, 100); 
      janela.setVisible(true); 
   } 
} 
