

import javax.swing.JFrame;

public class TesteJanelaTextoImagem 
{
   public static void main(String[] args){ 
      JanelaTextoImagem labelFrame = new JanelaTextoImagem(); 
      labelFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      labelFrame.setSize(260, 180); 
      labelFrame.setVisible(true); 
   } 
} 


