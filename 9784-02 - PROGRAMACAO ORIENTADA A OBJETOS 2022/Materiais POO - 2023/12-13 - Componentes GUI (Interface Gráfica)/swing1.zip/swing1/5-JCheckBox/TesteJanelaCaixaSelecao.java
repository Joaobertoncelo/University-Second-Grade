import javax.swing.JFrame;

public class TesteJanelaCaixaSelecao{
   public static void main(String[] args)
   { 
      JanelaCaixaSelecao janela = new JanelaCaixaSelecao(); 
      janela.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      janela.setSize(275, 100); 
      janela.setVisible(true); 
   } 
} 
