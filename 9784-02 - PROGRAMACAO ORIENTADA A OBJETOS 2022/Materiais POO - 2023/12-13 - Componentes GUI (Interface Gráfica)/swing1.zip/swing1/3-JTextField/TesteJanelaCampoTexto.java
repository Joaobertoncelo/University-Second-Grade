import javax.swing.JFrame;

public class TesteJanelaCampoTexto{
   public static void main(String[] args){ 
      JanelaCampoTexto textFieldFrame = new JanelaCampoTexto(); 
      textFieldFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      textFieldFrame.setSize(350, 100); 
      textFieldFrame.setVisible(true); 
   } 
} 
