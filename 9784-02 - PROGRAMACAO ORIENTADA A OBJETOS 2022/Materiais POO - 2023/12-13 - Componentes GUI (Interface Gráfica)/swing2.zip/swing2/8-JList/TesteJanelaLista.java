
import javax.swing.JFrame;

public class TesteJanelaLista 
{
   public static void main(String[] args)
   { 
      JanelaLista janela = new JanelaLista();
      janela.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      janela.setSize(350, 150); 
      janela.setVisible(true); 
   } 
} 
