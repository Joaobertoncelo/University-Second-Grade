
import javax.swing.JFrame;

public class TesteJanelaEventosTeclas 
{
   public static void main(String[] args)
   { 
      JanelaEventosTeclas janela = new JanelaEventosTeclas(); 
      janela.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      janela.setSize(350, 100); 
      janela.setVisible(true); 
   } 
} 
