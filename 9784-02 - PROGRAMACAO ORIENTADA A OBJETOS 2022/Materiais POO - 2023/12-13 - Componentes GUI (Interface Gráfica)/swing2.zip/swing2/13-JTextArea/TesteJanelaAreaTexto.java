
import javax.swing.JFrame;

public class TesteJanelaAreaTexto
{
   public static void main(String[] args)
   { 
      JanelaAreaTexto janela = new JanelaAreaTexto(); 
      janela.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      janela.setSize(425, 200); 
      janela.setVisible(true); 
   } 
}
