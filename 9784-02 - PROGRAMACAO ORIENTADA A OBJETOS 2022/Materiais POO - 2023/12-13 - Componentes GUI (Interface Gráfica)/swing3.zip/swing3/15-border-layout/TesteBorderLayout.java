import javax.swing.JFrame;

public class TesteBorderLayout {
   public static void main(String[] args)
   { 
      JanelaBorderLayout janela = new JanelaBorderLayout(); 
      janela.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      janela.setSize(300, 200); 
      janela.setVisible(true); 
   } 
} 
