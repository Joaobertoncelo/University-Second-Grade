import javax.swing.JFrame;

public class TesteGridLayout {
   public static void main(String[] args)
   { 
      JanelaGridLayout janela = new JanelaGridLayout(); 
      janela.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      janela.setSize(300, 200); 
      janela.setVisible(true); 
   } 
} 
