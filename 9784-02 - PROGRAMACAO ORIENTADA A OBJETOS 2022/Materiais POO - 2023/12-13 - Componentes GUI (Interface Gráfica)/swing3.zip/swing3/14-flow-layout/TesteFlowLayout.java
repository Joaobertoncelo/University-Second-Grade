import javax.swing.JFrame;

public class TesteFlowLayout {
   public static void main(String[] args){ 
      JanelaFlowLayout janela = new JanelaFlowLayout(); 
      janela.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      janela.setSize(300, 75); 
      janela.setVisible(true); 
   } 
}
