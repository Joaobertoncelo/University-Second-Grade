/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lista03;

/**
 *
 * @author lilian
 */
public class Ex01GraficoBarras {
    
    public static void main(String[] args) {
        int[] array = {0, 0, 0, 0, 0, 0, 1, 2, 4, 2, 1};
        System.out.println("Distribuição das notas:");
    
        // for each array element, output a bar of the chart
        for (int i = 0; i < array.length; i++) {
            // output bar label ("00-09: ", ..., "90-99: ", "100: ")
            if (i == 10) {
                System.out.printf("%5d: ", 100);
            }
            else {
                System.out.printf("%02d-%02d: ",
                                i * 10, i * 10 + 9);
            }
            // print bar of asterisks
            for (int stars = 0; stars < array[i]; stars++) {
                System.out.print("*");
            }

            System.out.println();

        }
    }
}
