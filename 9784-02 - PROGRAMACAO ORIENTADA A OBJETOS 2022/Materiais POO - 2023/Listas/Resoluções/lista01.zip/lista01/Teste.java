/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lista01;

import java.util.Scanner;

/**
 *
 * @author lilian
 */
public class Teste {
    
     public static void main(String[] args){
        /* Exercício 1 */
        // Entrada
        
        termosNecessariosPi();
        
    }

    /* Exercício 1 */
    public static void imprimirInteiroEspacado(int numeroInteiro){
       String stringNumeroInteiro = Integer.toString(numeroInteiro);

       for(int i = 0; i < stringNumeroInteiro.length(); i++){
            System.out.print(stringNumeroInteiro.charAt(i) + "   ");
       }

       System.out.println(); // Quebrar a linha
    }

    /* Exercício 2 */
    public static void imprimirQuadradosECubosZeroADez(){
        String numero = "numero";
        String quadrado = "quadrado";
        String cubo = "cubo";
        String espaco = "  ";

        System.out.println(numero + espaco + quadrado + espaco + cubo);

        for(int i = 0; i <= 10; i++){
            System.out.println(formatarEspacos(Integer.toString(i), numero.length()) + espaco +
                                formatarEspacos(Integer.toString(i * i), quadrado.length()) + espaco + 
                                Integer.toString(i * i * i));  
        }
    }

    /* Exercício 3 */
    public static void imprimirTabelaSeriePiPrimeirosCemTermos(){
        String numero = "numero";
        String piCalculado = "Pi calculado";
        String espaco = "  ";

        System.out.println(numero + espaco + piCalculado);

        double pi = 0;
        double soma = 0;

        for (int i = 1; i <= 100; i++)
        {
            soma += Math.pow(-1,i+1) / (2*i - 1);

            pi = 4 * soma;

            System.out.println(formatarEspacos(Integer.toString(i), numero.length()) + espaco + pi);
        }
    }

    public static void termosNecessariosPi(){
        double pi = 0;
        double soma = 0;

        String compare = "3.14159";

        for (int i = 1; ; i++)
        {
            soma += Math.pow(-1,i+1) / (2*i - 1);

            pi = 4 * soma;
            
            if (i != 1) {
                String c = Double.toString(pi).substring(0, compare.length());
                if (c.equals(compare)) {
                    System.out.println("Numero: " + i);
                    break;
                }
            }
        }
    }

    /* Função Auxiliar */
    public static String formatarEspacos(String texto, int tamanho){
        for(int i = texto.length(); i < tamanho; i++){
            texto += " ";
        }
        return texto;
    }
  
}
