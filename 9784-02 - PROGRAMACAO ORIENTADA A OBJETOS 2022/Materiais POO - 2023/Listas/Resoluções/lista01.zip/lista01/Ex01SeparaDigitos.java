package lista01;

import java.util.Scanner;

/**
 * Escreva um programa que recebe como entrada um número inteiro, separa-o em seus dígitos
   individuais e imprime os dígitos separados uns dos outros por três espaços. Por exemplo, se o
   usuário digitar o número 42339, o programa deve imprimir: 4   2   3   3  9
 * @author lilian
 */
public class Ex01SeparaDigitos {
    
    
    public static void main(String[] args) {
        
        System.out.print("Insira um número inteiro: ");
        
        Scanner in = new Scanner(System.in);
        int x = in.nextInt();
        
        System.out.println("");
        
        //quantos dígitos o número informado tem?
        int i;
        for(i=1; Math.pow(10, i) < x; i++);
        
        while(x>0){
            
            i--;
            
            int div = (int) Math.pow(10, i);
            
            int digito = x / div;
            
            System.out.print(digito+"   ");
            
            x -= digito*div;
            
        }
        
        
        
        
        
    }
    
}
