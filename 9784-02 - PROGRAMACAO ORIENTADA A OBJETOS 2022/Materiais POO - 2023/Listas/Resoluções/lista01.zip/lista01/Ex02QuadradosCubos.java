/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lista01;

/**
 * Escreva um programa que calcule os quadrados e cubos dos números de 0 a 10 e imprima os
   valores resultantes no formato de uma tabela, conforme o exemplo abaixo.
   * 
   * número  quadrado  cubo
   *   0        0        0
   *   1        1        1
   *   2        4        8
 * 
 * 
 * @author lilian
 */
public class Ex02QuadradosCubos {
    
    public static void main(String[] args) {
        
        System.out.printf("%8s  %8s  %8s %n", "número", "quadrado", "cubo");
        
        for(int num = 0; num <= 10; num++)
            System.out.printf("%8d  %8d  %8d %n", num, (int)Math.pow(num,2), (int)Math.pow(num,3));
        
    }
}
