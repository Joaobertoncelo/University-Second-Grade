/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lista01;

/**
 * Calcule o valor de π usando a série infinita:
 * PI = 4 - 4/3 + 4/5 - 4/7 + 4/9 - 4/11 + ...
 * @author lilian
 */
public class Ex03SeriePI {
    
    public static void main(String[] args) {
        
        double pi = 0;
        
        System.out.printf("%5s  %8s  %n", "i", "termo");
        
        int i;
        for(i=0; i<100; i++){
            
            pi += Math.pow(-1,i) * 4.0 / (double) (2*i+1);
            System.out.printf("%5d  %8.7f  %n", i+1, pi);
            
        }
        
        double valor = 3.14159;

        
        while( Math.abs(pi-valor) >= 0.0000001 ){
            
            
            
            pi += Math.pow(-1,i) * 4.0 / (double) (2*i+1);
            i++;
            
        }
        
        System.out.println("Primeiro termo que começa com 3,14159: ");
        System.out.printf("%5d  %8.7f  %n", i+1, pi);
        
    }
    
}
