/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lista04;

import java.util.Scanner;

/**
 *
 * @author lilian
 */
public class Ex01Args {
    public static void main(String[] args) {
        if (args.length > 0) {
            
            int maior, menor;
            
            maior = menor = Integer.parseInt(args[0]);
            
            for(String arg : args){
                int valor = Integer.parseInt(arg);
                if(valor > maior)
                    maior = valor;
                if(valor < menor)
                    menor = valor;
            }
            
            System.out.println("Média: "+ (float)(menor+maior)/2.0);
        }    
    }
}
