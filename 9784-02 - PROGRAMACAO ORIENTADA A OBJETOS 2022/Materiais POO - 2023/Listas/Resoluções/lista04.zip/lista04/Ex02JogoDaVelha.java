/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lista04;

import java.util.Scanner;

/**
 *
 * @author lilian
 */
public class Ex02JogoDaVelha {
    public static void main(String[] args) {
        int[][] matriz = { {2,0,1},
                           {2,1,0},
                           {1,0,0}
                         };
        
        System.out.println("Tabuleiro: ");
        for(int[] linha : matriz){
            for(int elemento : linha)
                System.out.printf("%3d ",elemento);
            System.out.println("");
        }    
                
            
        
        System.out.print("\nInforme o jogador a ser verificado: ");
        
        Scanner in = new Scanner(System.in);
        int j = in.nextInt();
        
        if(verificaGanhador(matriz, j))
            System.out.println("\nJogador "+j+" ganhou!\n");
        else
            System.out.println("\nJogador "+j+" não ganhou.\n");
        
    }
    
    public static boolean verificaGanhador(int[][] tabuleiro, int jogador){
        return( ( tabuleiro[0][0] == jogador && tabuleiro[0][1] == jogador && tabuleiro[0][2] == jogador ) || 
                ( tabuleiro[1][0] == jogador && tabuleiro[1][1] == jogador && tabuleiro[1][2] == jogador ) || 
                ( tabuleiro[2][0] == jogador && tabuleiro[2][1] == jogador && tabuleiro[2][2] == jogador ) || 
                ( tabuleiro[0][0] == jogador && tabuleiro[1][0] == jogador && tabuleiro[2][0] == jogador ) || 
                ( tabuleiro[0][1] == jogador && tabuleiro[1][1] == jogador && tabuleiro[2][1] == jogador ) || 
                ( tabuleiro[0][2] == jogador && tabuleiro[1][2] == jogador && tabuleiro[2][2] == jogador ) || 
                ( tabuleiro[0][0] == jogador && tabuleiro[1][1] == jogador && tabuleiro[2][2] == jogador ) || 
                ( tabuleiro[0][2] == jogador && tabuleiro[1][1] == jogador && tabuleiro[2][0] == jogador ) 
              );

    }    
}
