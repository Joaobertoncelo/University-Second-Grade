/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lista02;

import java.util.Scanner;

/**
 *
 * @author lilian
 */
public class Ex03AnoBissexto {
    public static void main(String[] args) {
        int a;
        
        Scanner in = new Scanner(System.in);
        
        System.out.print("Insira um ano: ");
        a = in.nextInt();
        
        if(ehAnoBissexto(a))
            System.out.println("\n"+a+" é ano bissexto \n");
        else
            System.out.println("\n"+a+" não é ano bissexto \n");
    }
    
    public static boolean ehAnoBissexto(int ano){
        if(ano % 400 == 0)
            return true;
        else if(ano % 100 == 0)
            return false;
        else if(ano % 4 == 0)
            return true;
        return false;
    }
}
