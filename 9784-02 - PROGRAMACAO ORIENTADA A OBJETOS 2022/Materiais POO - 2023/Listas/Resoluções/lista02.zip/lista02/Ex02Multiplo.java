/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lista02;

import java.util.Scanner;

/**
 *
 * @author lilian
 */
public class Ex02Multiplo {
    public static void main(String[] args) {
        int n1, n2;
        
        Scanner in = new Scanner(System.in);
        
        System.out.print("Número 1: ");
        n1 = in.nextInt();
        
        System.out.print("Número 2: ");
        n2 = in.nextInt();
        
        if(ehMultiplo(n2, n1))
            System.out.println("\n"+n2+" é múltiplo de "+n1+"\n");
        else
            System.out.println("\n"+n2+" não é múltiplo de "+n1+"\n");
    }
    
    public static boolean ehMultiplo(int x, int y){
        return x % y == 0;  
    }
}
