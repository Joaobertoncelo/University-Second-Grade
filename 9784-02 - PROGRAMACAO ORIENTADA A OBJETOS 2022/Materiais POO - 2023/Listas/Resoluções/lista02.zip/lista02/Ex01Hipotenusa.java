/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lista02;

import java.util.Scanner;

/**
 *
 * @author lilian
 */
public class Ex01Hipotenusa {
    public static void main(String[] args) {
        
        double l1, l2, l3;
        
        System.out.println("Lados de um triângulo retângulo");
        System.out.println("");
        
        Scanner in = new Scanner(System.in);
        
        System.out.print("Lado 1: ");
        l1 = in.nextDouble();
        
        System.out.print("Lado 2: ");
        l2 = in.nextDouble();
        
        l3 = calculaHipotenusa(l1, l2);
        System.out.println("Lado 3: "+l3+"\n");
        
    }
    
    public static double calculaHipotenusa(double b, double c){
        double a = Math.sqrt(Math.pow(b, 2)+Math.pow(c, 2));
        return a;
    }
}
