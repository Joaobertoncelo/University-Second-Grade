#include <stdio.h>
#include <string.h>
#include <stdlib.h>

// declarar todas as funções
void remocao(char *chave, char *nomeDoArquivo);
void insercao(char *conteudo, char *nomeDoArquivo);
void buscar(char *chave, char *nomeDoArquivo);
void importar(char *nomeDoArquivo);
void imprimir_led();
void executar_operacoes(char *nomeDoArquivo);

int main(int argc, char *argv[])
{

    if (argc == 3 && strcmp(argv[1], "-i") == 0)
    {

        printf("Modo de importacao ativado ... nome do arquivo = %s\n", argv[2]);
        importar(argv[2]);
    }
    else if (argc == 3 && strcmp(argv[1], "-e") == 0)
    {

        printf("Modo de execucao de operacoes ativado ... nome do arquivo = %s\n", argv[2]);
        executar_operacoes(argv[2]);
    }
    else if (argc == 2 && strcmp(argv[1], "-p") == 0)
    {

        printf("Modo de impressao da LED ativado ...\n");
        imprimir_led();
    }
    else
    {

        fprintf(stderr, "Argumentos incorretos!\n");
        fprintf(stderr, "Modo de uso:\n");
        fprintf(stderr, "$ %s (-i|-e) nome_arquivo\n", argv[0]);
        fprintf(stderr, "$ %s -p\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    return 0;
}

void remocao(char *chave, char *nomeDoArquivo)
{
    FILE *arquivo;

    arquivo = fopen(nomeDoArquivo, "rb+");

    if (arquivo == NULL)
    {
        printf("Erro ao abrir o arquivo");
        exit(1);
    }

    char buffer[256];
    char linha[256];
    char *token;

    printf("Remocao do registro de chave %s\n", chave);

    while (fgets(buffer, 256, arquivo) != NULL)
    {
        fseek(arquivo, 2, SEEK_CUR);

        strcpy(linha, buffer);

        token = strtok(buffer, "|");

        if (strcmp(token, chave) == 0)
        {
            printf("Registro removido! (%ld bytes)\n", strlen(linha) - 1);
            printf("Local: offset = %ld bytes\n", ftell(arquivo) - strlen(linha) - 2);
            fseek(arquivo, -strlen(linha) - 2, SEEK_CUR);
            buffer[0] = '*';
            buffer[1] = '|';
            fwrite(buffer, 1, strlen(linha), arquivo);
            fclose(arquivo);
            return;
        }
    }

    printf("Erro: registro nao encontrado!\n");

    fclose(arquivo);
}

void insercao(char *conteudo, char *nomeDoArquivo)
{
    FILE *arquivo;
    // char buffer[256];
    char chave[256];
    char *token;
    short int bytesLidos = strlen(conteudo);
    int i = 0;

    arquivo = fopen(nomeDoArquivo, "rb+");
    if (arquivo == NULL)
    {
        printf("Erro ao abrir o arquivo");
        exit(1);
    }

    strcpy(chave, conteudo);

    token = strtok(chave, "|");

    printf("Insercao do registro %s\n", token);

    // while (fgets(buffer, 256, arquivo) != NULL)
    // {
    //     fseek(arquivo, 2, SEEK_CUR);
    //             printf(buffer);

    //     if (buffer[0] == '*')
    //     {
    //         if ((int)buffer[0] >= strlen(conteudo) + 1)
    //         {
    //             // fseek(arquivo, -strlen(buffer) -2, SEEK_CUR);
    //             // buffer[0] = conteudo[0];
    //             // buffer[1] = conteudo[1];
    //             // fwrite(buffer, 1, strlen(conteudo), arquivo);
    //             // fwrite("\r\n", 1, 2, arquivo);
    //             // printf("Registro inserido! (%ld bytes)\n", strlen(conteudo) - 1);
    //             // fwrite(conteudo, sizeof(char), strlen(conteudo), arquivo);
    //             // printf("Local: offset = %ld bytes\n", ftell(arquivo) - 3 - strlen(conteudo) * 2);
    //             fclose(arquivo);
    //             return;
    //         }
    //     }
    // }
    // se não achar nenhum registro removido com espaço suficiente, insere o novo registro no final do arquivo
    fseek(arquivo, 0, SEEK_END);
    // escreve \r\n
    fwrite("\r\n", 1, 2, arquivo);
    fwrite(&bytesLidos, sizeof(bytesLidos), 1, arquivo);
    fwrite(conteudo, sizeof(char), strlen(conteudo), arquivo);
    printf("Local: offset = final do arquivo\n");
    fclose(arquivo);
}

void buscar(char *chave, char *nomeDoArquivo)
{
    FILE *arquivo;

    arquivo = fopen(nomeDoArquivo, "rb");

    if (arquivo == NULL)
    {
        printf("Erro ao abrir o arquivo");
        exit(1);
    }

    char buffer[256];
    char linha[256];
    char *token;

    printf("Buscando pelo registro de chave %s\n", chave);

    while (fgets(buffer, 256, arquivo) != NULL)
    {
        strcpy(linha, buffer);
        fseek(arquivo, 2, SEEK_CUR);

        token = strtok(buffer, "|");

        if (strcmp(token, chave) == 0)
        {
            printf("%s (%ld bytes)\n", linha, strlen(linha) - 1);
            fclose(arquivo);
            return;
        }
    }

    printf("Erro: chave nao encontrada");

    fclose(arquivo);
}

void importar(char *nomeDoArquivo)
{
    FILE *arquivo, *dadosEmMemoria;
    char buffer[256];
    int tamanho;
    short int bytesLidos;

    arquivo = fopen(nomeDoArquivo, "r");
    dadosEmMemoria = fopen("dados.dat", "wb");

    if (arquivo == NULL)
    {
        printf("Erro ao abrir o arquivo\n");
        exit(1);
    }

    while (!feof(arquivo))
    {
        buffer[0] = '\0';
        fgets(buffer, 256, arquivo);

        tamanho = strlen(buffer);
        bytesLidos = strlen(buffer);

        fwrite(&bytesLidos, sizeof(bytesLidos), 1, dadosEmMemoria);
        fwrite(buffer, sizeof(char), tamanho, dadosEmMemoria);
    }

    fclose(arquivo);

    printf("Arquivo importado com sucesso\n");

    fclose(dadosEmMemoria);
}

void imprimir_led()
{
    FILE *arquivo;
    char buffer[256];

    arquivo = fopen("dados.dat", "rb");

    if (arquivo == NULL)
    {
        printf("Erro ao abrir o arquivo");
        exit(1);
    }

    while (fgets(buffer, 256, arquivo) != NULL)
    {
        if (buffer[2] == '*')
        {
            fseek(arquivo, -2, SEEK_CUR);
            printf("Byte offset: %ld\n", ftell(arquivo));
        }
    }

    fclose(arquivo);
}

void executar_operacoes(char *nomeDoArquivo)
{
    FILE *arquivoDeOperacoes;
    char arquivo[256];
    char buffer[256];
    char *operacao[1];
    char *chave;

    printf("Digite o arquivo que fara as operacoes: ");
    scanf("%s", arquivo);

    arquivoDeOperacoes = fopen(arquivo, "rb");

    if (arquivoDeOperacoes == NULL)
    {
        printf("Erro ao abrir o arquivo\n");
        exit(1);
    }

    while (!feof(arquivoDeOperacoes))
    {
        buffer[0] = '\0';
        fgets(buffer, 256, arquivoDeOperacoes);

        operacao[0] = strtok(buffer, " ");
        chave = strtok(NULL, "\r");
        if (strcmp(operacao[0], "i") == 0)
        {
            insercao(chave, nomeDoArquivo);
        }
        else if (strcmp(operacao[0], "b") == 0)
        {
            buscar(chave, nomeDoArquivo);
        }
        else if (strcmp(operacao[0], "r") == 0)
        {
            remocao(chave, nomeDoArquivo);
        }
        else
        {
            printf("Operacao invalida\n");
        }
    }

    fclose(arquivoDeOperacoes);
}
